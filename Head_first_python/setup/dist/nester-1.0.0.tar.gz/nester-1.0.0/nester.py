import nester 

cast = ['Palin', 'Clease', 'Idle', 'Jone', 'Giliam']

nester.print_lol(cast)